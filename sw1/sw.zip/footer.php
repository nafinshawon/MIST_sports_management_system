<div id="footer" >
	  <a href="#">MIST Sports Management System</a>
  </div><!--close footer-->  