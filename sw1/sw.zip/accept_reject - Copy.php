 <!DOCTYPE html ><!--PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd">-->
<?php include "header.php"; ?>
<div id="menubar">
  
      <ul id="menu">
        <!--<a href="index.php"><img src="images/mistlogo.png" alt="" width="180" height="170"/></a>-->
        <li ><a href="index.php">Home</a></li>
        <li class="current"><a href="year_schedule.php">Year Schedule</a></li>
        <li  ><a href="archive.php">Archive</a></li>
        <li><a href="signup.php">Sign Up</a></li>
      </ul>
    </div><!--close menubar-->

    <div id="slideshow">
    <ul class="slideshow">
        <li class="show"><img width="920" height="250" src="images/home_1.jpg" alt="&quot;Enter your caption here&quot;" /></li>
        <li><img width="920" height="250" src="images/home_2.jpg" alt="&quot;Enter your caption here&quot;" /></li>
      </ul> 
    </div><!--close slidesho-->     
  
  <div id="header">
    <div id="banner">
      <div id="welcome">
        <h1>MIST Sports Management System</h1>
      </div><!--close welcome-->
    </div><!--close banner-->
    </div><!--close header-->

    <div id="site_content">  

      <div style="margin-top:5%">
            <h1 class="con">Player Selection </h1>
        
         </div>

<table>
  <tr>
    <th style="width:15%;"><h3></h3></th>
    <th><h3>Name</h3></th>
    <th><h3>ID</h3></th>
    <th><h3>Department</h3></th>
    <th><h3>Level</h3></th>
    <th><h3>Event Name</h3></th>
  </tr>
  <tr>
    <td>
      <form action="">
<input type="checkbox" name="ch1" value="cch1">
</form>
    </td>
    <td>Maria Anders</td>
    <td>Germany</td>
    <td>Maria Anders</td>
    <td>Germany</td>
      <td>Germany</td>
  </tr>
  <tr>
    <td>
      <form action="">
<input type="checkbox" name="ch2" value="cch2">
</form>
    </td>
    <td>Francisco Chang</td>
    <td>Mexico</td>
   <td>Maria Anders</td>
    <td>Germany</td>
      <td>Germany</td>
  </tr>
  <tr>
    <td>
      <form action="">
<input type="checkbox" name="ch3" value="cch3">
</form>
    </td>
    <td>Roland Mendel</td>
    <td>Austria</td>
    <td>Maria Anders</td>
    <td>Germany</td>
      <td>Germany</td>
  </tr>
  <tr>
    <td>
      <form action="">
<input type="checkbox" name="ch4" value="cch4">
</form>
    </td>
    <td>Helen Bennett</td>
    <td>UK</td>
    <td>Maria Anders</td>
    <td>Germany</td>
      <td>Germany</td>
  </tr>
  <tr>
    <td>
      <form action="">
<input type="checkbox" name="ch5" value="cch5">
</form>
    </td>
    <td>Yoshi Tannamuri</td>
    <td>Canada</td>
    <td>Maria Anders</td>
    <td>Germany</td>
      <td>Germany</td>
  </tr>
  <tr>
    <td>
      <form action="">
<input type="checkbox" name="ch6" value="cch6">
</form>
    </td>
    <td>Giovanni Rovelli</td>
    <td>Italy</td>
    <td>Maria Anders</td>
    <td>Germany</td>
      <td>Germany</td>
  </tr>
</table>

 <div class="content_container" style="margin-bottom:3%;margin-top:2%;">
         
        <div class="button_small" style="font-weight:700">
          <a href="">Accept</a>
          
        </div><!--close button_small-->
      </div><!--close content_container-->  

       <div class="content_container" style="margin-bottom:3%;margin-top:2%;">
         
        <div class="button_small" style="font-weight:700">
          <a href="">Reserve</a>
          
        </div><!--close button_small-->
      </div><!--close content_container-->  

       <div class="content_container" style="margin-bottom:3%;margin-top:2%;">
         
        <div class="button_small" style="font-weight:700">
          <a href="">Reject</a>
          
        </div><!--close button_small-->
      </div><!--close content_container-->  

    </div>



     <div id="content_grey">
        <?php include "footer.php"; ?>
    <br style="clear:both"/>
    </div><!--close content_grey-->   
 
  </div><!--close main-->
  
  
  
</body>
</html>
