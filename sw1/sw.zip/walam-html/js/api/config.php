<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'your consumer Key here');
    define('CONSUMER_SECRET', 'your consumer secret Key here');

    // User Access Token
    define('ACCESS_TOKEN', 'your access token here');
    define('ACCESS_SECRET', 'your access secret Key here');